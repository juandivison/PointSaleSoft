object FrmFpEnroll: TFrmFpEnroll
  Left = 336
  Top = 213
  BorderStyle = bsDialog
  Caption = 'Enrolamiento de huella'
  ClientHeight = 151
  ClientWidth = 438
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object lblInfo: TLabel
    Left = 16
    Top = 16
    Width = 402
    Height = 13
    Caption = 'Coloque el dedo en el lector para registrar la huella...'
  end
  object btnClose: TButton
    Left = 336
    Top = 112
    Width = 89
    Height = 25
    Caption = 'Cerrar'
    TabOrder = 0
    OnClick = btnCloseClick
  end
  object DPFPEnrollmentControl1: TDPFPEnrollmentControl
    Left = 8
    Top = 8
    Width = 1
    Height = 1
    Visible = True
    TabOrder = 1
    OnEnroll = DPFPEnrollmentControl1Enroll
    ControlData = {
      00000000}
  end
end
