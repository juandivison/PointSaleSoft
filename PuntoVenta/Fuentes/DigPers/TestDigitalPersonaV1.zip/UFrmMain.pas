unit UFrmMain;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, DPFPCtlXLib_TLB, OleCtrls, StdCtrls, IBCustomDataSet, IBQuery,
  DB, IBTable;

type
  TForm1 = class(TForm)
    Button1: TButton;
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation
  uses UFrmFpEnroll;
  
{$R *.dfm}

procedure TForm1.Button1Click(Sender: TObject);
var
  F: TFrmFpEnroll;
begin
  F := TFrmFpEnroll.Create(Application);
  try
    F.DB := dm.IBDatabase1;
    F.TR := dm.IBTransaction1;
    F.CodUsuario := USUARIO_NUMERO; // <-- USUARIO.NUMERO
    F.ShowModal; // el form guarda templates en OnEnroll
  finally
    F.Free;
  end;
end;

end.

