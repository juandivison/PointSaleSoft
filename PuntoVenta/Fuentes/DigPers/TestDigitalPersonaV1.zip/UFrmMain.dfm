object Form1: TForm1
  Left = 283
  Top = 352
  Width = 1305
  Height = 675
  Caption = 'Setup Credenciales'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object Button1: TButton
    Left = 16
    Top = 16
    Width = 95
    Height = 25
    Caption = 'Configurar Huellas'
    TabOrder = 0
    OnClick = Button1Click
  end
end
