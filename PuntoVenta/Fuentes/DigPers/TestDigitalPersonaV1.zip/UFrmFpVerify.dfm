object FrmFpVerify: TFrmFpVerify
  Left = 347
  Top = 215
  BorderStyle = bsDialog
  Caption = 'Autorización por huella'
  ClientHeight = 151
  ClientWidth = 418
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object lblInfo: TLabel
    Left = 16
    Top = 16
    Width = 385
    Height = 13
    Caption = 'Coloque el dedo en el lector para autorizar la operación...'
  end
  object btnCancel: TButton
    Left = 312
    Top = 112
    Width = 89
    Height = 25
    Caption = 'Cancelar'
    TabOrder = 0
    OnClick = btnCancelClick
  end
  object DPFPVerificationControl1: TDPFPVerificationControl
    Left = 8
    Top = 8
    Width = 1
    Height = 1
    Visible = True
    TabOrder = 1
    OnComplete = DPFPVerificationControl1Complete
    ControlData = {
      00000000}
  end
end
