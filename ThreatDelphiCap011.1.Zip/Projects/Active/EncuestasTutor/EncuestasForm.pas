unit EncuestasForm;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs, mbox,
  ActnList, ImgList, Menus, ComCtrls, ToolWin, Grids, DBGrids, Db, ExtCtrls,
  TeeProcs, TeEngine, Chart, DBChart, Series, StdCtrls, Buttons, DBCtrls;

type
  Tmainform = class(TForm)
    ImageList1: TImageList;
    ActionList1: TActionList;
    Import: TAction;
    MainMenu1: TMainMenu;
    Archivo1: TMenuItem;
    ImportarMBox1: TMenuItem;
    ToolBar1: TToolBar;
    tbImportar: TToolButton;
    DataSource1: TDataSource;
    DBGrid1: TDBGrid;
    OpenMBox: TOpenDialog;
    Panel1: TPanel;
    StatusBar1: TStatusBar;
    ProgressBar1: TProgressBar;
    DBChart1: TDBChart;
    sMejorCapitulo: TPieSeries;
    sPeorCapitulo: TPieSeries;
    sQueTanBueno: TPieSeries;
    sEntendido: TPieSeries;
    cbStatistic: TComboBox;
    Label1: TLabel;
    ToolButton1: TToolButton;
    ToolButton4: TToolButton;
    Mostrar: TAction;
    BitBtn1: TBitBtn;
    Splitter1: TSplitter;
    procedure ImportExecute(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure MostrarExecute(Sender: TObject);
    procedure DBGrid1CellClick(Column: TColumn);
  private
    { Private declarations }
    procedure EscondeSeries;
    procedure MuestraSerie( DataSet : TDataSet );
    procedure MuestraDatos( DataSet : TDataSet );
  public
    { Public declarations }
  end;

var
  mainform: Tmainform;

implementation

uses dmEncuestas, showBlob;

{$R *.DFM}

procedure Tmainform.ImportExecute(Sender: TObject);
var
 Archivo : TFileName;
begin


 if OpenMBox.execute then begin
   Archivo := OpenMBox.FileName;
   EncuestasDM.StartParsing(Archivo);
 end;


end;

procedure Tmainform.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin

  CanClose := EncuestasDM.Busy;

end;

procedure Tmainform.MostrarExecute(Sender: TObject);
begin

  //
  case cbStatistic.ItemIndex of
     0 : MuestraDatos(EncuestasDM.qStatsQueTanBueno);
     1 : MuestraDatos(EncuestasDM.qStatsEntendimiento);
     2 : MuestraDatos(EncuestasDM.qStatsMejorCapitulo);
     3 : MuestraDatos(EncuestasDM.qStatsPeorCapitulo);
     4 : MuestraDatos(EncuestasDM.qVistaCompleta);

    else ShowMessage('Esa estad�stica no existe!');
  end;

end;

procedure Tmainform.MuestraSerie( DataSet : TDataSet );
var
  i : Integer;
begin

  for i := 0 to DBChart1.SeriesList.Count-1 do
     if DBChart1.SeriesList.Series[i].DataSource = DataSet then DBChart1.SeriesList.Series[i].Active := True;
  DBChart1.Visible := True;
  Splitter1.Visible := True;

end;

procedure Tmainform.EscondeSeries;
var
 i : Integer;
begin

  for i := 0 to DBChart1.SeriesList.Count-1 do
     DBChart1.SeriesList.Series[i].Active := False;

  DBChart1.Visible := False;
  Splitter1.Visible := False;

end;


procedure Tmainform.MuestraDatos( DataSet : TDataSet );
var
  bEsconder : Boolean;
  i : Integer;
begin

  //
  EscondeSeries;
  bEsconder := True;
  for i := 0 to DBChart1.SeriesList.Count-1 do
     if DBChart1.SeriesList.Series[i].DataSource = DataSet then bEsconder := False;

  EscondeSeries;
  if not bEsconder then MuestraSerie(DataSet); 

  DataSource1.DataSet := DataSet;
  if DataSet.Active then DataSet.Close;
  DataSet.Open;

end;


procedure Tmainform.DBGrid1CellClick(Column: TColumn);
begin

  //
  if Column.Field.DataType = ftMemo then begin
    frmBlob.DataSource1.DataSet := DataSource1.DataSet;
    frmBlob.DBMemo1.DataField := '';
    frmBlob.Caption := Column.Field.DisplayName;
    frmBlob.DBMemo1.DataField := Column.Field.FieldName;
    frmBlob.Show; 
  end;

end;

end.
