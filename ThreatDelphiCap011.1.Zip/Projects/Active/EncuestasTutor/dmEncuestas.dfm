object EncuestasDM: TEncuestasDM
  OldCreateOrder = False
  OnCreate = DataModuleCreate
  OnDestroy = DataModuleDestroy
  Left = 87
  Top = 129
  Height = 661
  Width = 898
  object ssSession: TSession
    SessionName = 'ssSession_1'
    Left = 24
    Top = 16
  end
  object dbEncuestas: TDatabase
    AliasName = 'Einstein'#39's WebStuff'
    DatabaseName = 'DbEncuestas'
    Params.Strings = (
      'USER NAME=david')
    SessionName = 'ssSession_1'
    Left = 88
    Top = 16
  end
  object qCapitulos: TQuery
    DatabaseName = 'DbEncuestas'
    SessionName = 'ssSession_1'
    SQL.Strings = (
      'SELECT * FROM Capitulos')
    Left = 88
    Top = 88
    object qCapitulosCapitulo: TSmallintField
      DisplayLabel = 'Cap�tulo'
      FieldName = 'Capitulo'
      Origin = 'DBENCUESTAS.Capitulos.Capitulo'
    end
    object qCapitulosDescripcion: TStringField
      DisplayLabel = 'Descripci�n'
      FieldName = 'Descripcion'
      Origin = 'DBENCUESTAS.Capitulos.Descripcion'
      FixedChar = True
      Size = 30
    end
  end
  object qEntendido: TQuery
    DatabaseName = 'DbEncuestas'
    SessionName = 'ssSession_1'
    SQL.Strings = (
      'SELECT * FROM Entendido')
    Left = 424
    Top = 368
    object qEntendidoQueTantoEntendio: TSmallintField
      DisplayLabel = 'Nivel Entendido'
      FieldName = 'QueTantoEntendio'
      Origin = 'DBENCUESTAS.Entendido.QueTantoEntendio'
    end
    object qEntendidoDescripcion: TStringField
      DisplayLabel = 'Descripci�n'
      FieldName = 'Descripcion'
      Origin = 'DBENCUESTAS.Entendido.Descripcion'
      FixedChar = True
      Size = 22
    end
  end
  object qOpinion: TQuery
    DatabaseName = 'DbEncuestas'
    SessionName = 'ssSession_1'
    SQL.Strings = (
      'SELECT * FROM QueTanBueno')
    Left = 432
    Top = 376
    object qOpinionQueBueno: TSmallintField
      FieldName = 'QueBueno'
      Origin = 'DBENCUESTAS.QueTanBueno.QueBueno'
      ProviderFlags = [pfInUpdate, pfInWhere, pfInKey]
    end
    object qOpinionDescripcion: TStringField
      DisplayLabel = 'Descripci�n'
      FieldName = 'Descripcion'
      Origin = 'DBENCUESTAS.QueTanBueno.Descripcion'
      FixedChar = True
      Size = 11
    end
  end
  object qGente: TQuery
    DatabaseName = 'DbEncuestas'
    SessionName = 'ssSession_1'
    SQL.Strings = (
      'SELECT * FROM People')
    Left = 440
    Top = 384
    object qGenteEMail: TStringField
      DisplayLabel = 'Correo'
      FieldName = 'EMail'
      Origin = 'DBENCUESTAS.People.EMail'
      FixedChar = True
      Size = 128
    end
    object qGenteName: TStringField
      DisplayLabel = 'Nombre'
      FieldName = 'Name'
      Origin = 'DBENCUESTAS.People.Name'
      FixedChar = True
      Size = 128
    end
    object qGenteDefaultLanguage: TStringField
      DisplayLabel = 'Lenguaje Default'
      FieldName = 'DefaultLanguage'
      Origin = 'DBENCUESTAS.People.DefaultLanguage'
      FixedChar = True
      Size = 128
    end
  end
  object qDelphiEncuestas: TQuery
    DatabaseName = 'DbEncuestas'
    SessionName = 'ssSession_1'
    DataSource = DataSource1
    SQL.Strings = (
      'SELECT * FROM DelphiEncuestas')
    Left = 448
    Top = 392
    object qDelphiEncuestasEMail: TStringField
      FieldName = 'EMail'
      Origin = 'DBENCUESTAS.DelphiEncuestas.EMail'
      Size = 128
    end
    object qDelphiEncuestasFecha: TDateTimeField
      FieldName = 'Fecha'
      Origin = 'DBENCUESTAS.DelphiEncuestas.Fecha'
    end
    object qDelphiEncuestasCursoBueno: TSmallintField
      FieldName = 'CursoBueno'
      Origin = 'DBENCUESTAS.DelphiEncuestas.CursoBueno'
    end
    object qDelphiEncuestasMejorCapitulo: TSmallintField
      FieldName = 'MejorCapitulo'
      Origin = 'DBENCUESTAS.DelphiEncuestas.MejorCapitulo'
    end
    object qDelphiEncuestasPeorCapitulo: TSmallintField
      FieldName = 'PeorCapitulo'
      Origin = 'DBENCUESTAS.DelphiEncuestas.PeorCapitulo'
    end
    object qDelphiEncuestasQueTantoEntendio: TSmallintField
      FieldName = 'QueTantoEntendio'
      Origin = 'DBENCUESTAS.DelphiEncuestas.QueTantoEntendio'
    end
    object qDelphiEncuestasComentarios: TMemoField
      FieldName = 'Comentarios'
      Origin = 'DBENCUESTAS.DelphiEncuestas.Comentarios'
      BlobType = ftMemo
      Size = 1
    end
  end
  object DataSource1: TDataSource
    DataSet = qGente
    Left = 456
    Top = 400
  end
  object qStatsMejorCapitulo: TQuery
    DatabaseName = 'DbEncuestas'
    SessionName = 'ssSession_1'
    SQL.Strings = (
      
        'SELECT Distinct Descripcion, Count(MejorCapitulo) AS Cuenta FROM' +
        ' DelphiEncuestas enc'
      'LEFT Join Capitulos ref ON ref.Capitulo = enc.MejorCapitulo'
      'group by MejorCapitulo'
      'Order By Cuenta DESC')
    Left = 464
    Top = 408
    object qStatsMejorCapituloDescripcion: TStringField
      FieldName = 'Descripcion'
      Origin = 'DBENCUESTAS.Capitulos.Descripcion'
      FixedChar = True
      Size = 30
    end
    object qStatsMejorCapituloCuenta: TFloatField
      FieldName = 'Cuenta'
      Origin = 'DBENCUESTAS.DelphiEncuestas.MejorCapitulo'
    end
  end
  object qStatsPeorCapitulo: TQuery
    DatabaseName = 'DbEncuestas'
    SessionName = 'ssSession_1'
    SQL.Strings = (
      
        'SELECT Distinct Descripcion, Count(PeorCapitulo) AS Cuenta FROM ' +
        'DelphiEncuestas enc'
      'LEFT Join Capitulos ref ON ref.Capitulo = enc.PeorCapitulo'
      'group by PeorCapitulo'
      'Order By Cuenta DESC')
    Left = 472
    Top = 416
    object qStatsPeorCapituloDescripcion: TStringField
      DisplayLabel = 'Descripci�n'
      FieldName = 'Descripcion'
      Origin = 'DBENCUESTAS.Capitulos.Descripcion'
      FixedChar = True
      Size = 30
    end
    object qStatsPeorCapituloCuenta: TFloatField
      FieldName = 'Cuenta'
      Origin = 'DBENCUESTAS.DelphiEncuestas.PeorCapitulo'
    end
  end
  object qStatsQueTanBueno: TQuery
    DatabaseName = 'DbEncuestas'
    SessionName = 'ssSession_1'
    SQL.Strings = (
      
        'SELECT Distinct Descripcion, Count(CursoBueno) FROM DelphiEncues' +
        'tas enc'
      'LEFT Join QueTanBueno ref ON ref.QueBueno = enc.CursoBueno'
      'group by CursoBueno')
    Left = 480
    Top = 424
    object qStatsQueTanBuenoDescripcion: TStringField
      DisplayLabel = 'Descripci�n'
      FieldName = 'Descripcion'
      Origin = 'DBENCUESTAS.QueTanBueno.Descripcion'
      FixedChar = True
      Size = 11
    end
    object qStatsQueTanBuenoCountCursoBueno: TFloatField
      DisplayLabel = 'Opini�n'
      FieldName = 'Count(CursoBueno)'
      Origin = 'DBENCUESTAS.DelphiEncuestas.CursoBueno'
    end
  end
  object qStatsEntendimiento: TQuery
    DatabaseName = 'DbEncuestas'
    SessionName = 'ssSession_1'
    SQL.Strings = (
      
        'SELECT Distinct Descripcion, Count(enc.QueTantoEntendio) FROM De' +
        'lphiEncuestas enc'
      
        'LEFT Join Entendido ref ON ref.QueTantoEntendio = enc.QueTantoEn' +
        'tendio'
      'group by enc.QueTantoEntendio')
    Left = 488
    Top = 432
    object qStatsEntendimientoDescripcion: TStringField
      FieldName = 'Descripcion'
      Origin = 'DBENCUESTAS.Entendido.Descripcion'
      FixedChar = True
      Size = 22
    end
    object qStatsEntendimientoCountencQueTantoEntendio: TFloatField
      DisplayLabel = 'Cuenta'
      FieldName = 'Count(enc.QueTantoEntendio)'
      Origin = 'DBENCUESTAS.DelphiEncuestas.QueTantoEntendio'
    end
  end
  object qVistaCompleta: TQuery
    DatabaseName = 'DbEncuestas'
    SessionName = 'ssSession_1'
    SQL.Strings = (
      'SELECT '
      '   People.Name, '
      '   enc.Email, '
      '   Mejor.Descripcion AS MejorCapitulo,'
      '   Peor.Descripcion AS PeorCapitulo,'
      
        '   ref.Descripcion As Opinion, Entendido.Descripcion AS Entendid' +
        'o,'
      '   comentarios'
      'FROM DelphiEncuestas enc'
      'LEFT JOIN QueTanBueno ref ON QueBueno = CursoBueno'
      
        'LEFT Join Entendido ON Entendido.QueTantoEntendio = enc.QueTanto' +
        'Entendio'
      'LEFT JOIN People on People.EMail = enc.EMail'
      'LEFT JOIN Capitulos Mejor on Mejor.Capitulo = MejorCapitulo'
      'LEFT JOIN Capitulos Peor on Peor.Capitulo = PeorCapitulo')
    Left = 496
    Top = 440
    object qVistaCompletaName: TStringField
      DisplayLabel = 'Nombre'
      FieldName = 'Name'
      FixedChar = True
      Size = 59
    end
    object qVistaCompletaEmail: TStringField
      DisplayLabel = 'Correo'
      FieldName = 'Email'
      Size = 40
    end
    object qVistaCompletaMejorCapitulo: TStringField
      DisplayLabel = 'Mejor'
      FieldName = 'MejorCapitulo'
      FixedChar = True
      Size = 30
    end
    object qVistaCompletaPeorCapitulo: TStringField
      DisplayLabel = 'Peor'
      FieldName = 'PeorCapitulo'
      FixedChar = True
      Size = 30
    end
    object qVistaCompletaOpinion: TStringField
      DisplayLabel = 'Opini�n'
      FieldName = 'Opinion'
      FixedChar = True
      Size = 11
    end
    object qVistaCompletaEntendido: TStringField
      FieldName = 'Entendido'
      FixedChar = True
      Size = 22
    end
    object qVistaCompletacomentarios: TMemoField
      FieldName = 'comentarios'
      BlobType = ftMemo
      Size = 1
    end
  end
  object ssThread: TSession
    Active = True
    SessionName = 'ssThread'
    SQLHourGlass = False
    Left = 328
    Top = 272
  end
  object dbThread: TDatabase
    AliasName = 'Einstein'#39's WebStuff'
    DatabaseName = 'dbThread'
    Params.Strings = (
      'USER NAME=david')
    SessionName = 'ssThread'
    Left = 336
    Top = 280
  end
end
