object frmBlob: TfrmBlob
  Left = 132
  Top = 163
  Width = 430
  Height = 312
  Caption = 'Memo'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 16
  object DBMemo1: TDBMemo
    Left = 0
    Top = 0
    Width = 422
    Height = 233
    Align = alClient
    DataField = 'comentarios'
    DataSource = DataSource1
    TabOrder = 0
  end
  object Panel1: TPanel
    Left = 0
    Top = 233
    Width = 422
    Height = 51
    Align = alBottom
    TabOrder = 1
    object Button1: TButton
      Left = 217
      Top = 10
      Width = 92
      Height = 31
      Caption = '&Cerrar'
      TabOrder = 0
      OnClick = Button1Click
    end
  end
  object DataSource1: TDataSource
    DataSet = EncuestasDM.qVistaCompleta
    Left = 8
    Top = 248
  end
end
