unit showBlob;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls, DBCtrls, Db;

type
  TfrmBlob = class(TForm)
    DBMemo1: TDBMemo;
    Panel1: TPanel;
    Button1: TButton;
    DataSource1: TDataSource;
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmBlob: TfrmBlob;

implementation

uses dmEncuestas;

{$R *.DFM}

procedure TfrmBlob.Button1Click(Sender: TObject);
begin
  Close;
end;

end.
