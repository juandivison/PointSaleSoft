program LectorEncuestas;

uses
  Forms,
  EncuestasForm in 'EncuestasForm.pas' {mainform},
  dmEncuestas in 'dmEncuestas.pas' {EncuestasDM: TDataModule},
  mbox in 'mbox.pas',
  MBoxParseThread in 'MBoxParseThread.pas',
  showBlob in 'showBlob.pas' {frmBlob};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(Tmainform, mainform);
  Application.CreateForm(TEncuestasDM, EncuestasDM);
  Application.CreateForm(TfrmBlob, frmBlob);
  Application.Run;
end.
