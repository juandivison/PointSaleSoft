unit dmEncuestas;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Db, DBTables, mbox;

type
  TEncuestasDM = class(TDataModule)
    ssSession: TSession;
    dbEncuestas: TDatabase;
    qCapitulos: TQuery;
    qCapitulosCapitulo: TSmallintField;
    qCapitulosDescripcion: TStringField;
    qEntendido: TQuery;
    qEntendidoQueTantoEntendio: TSmallintField;
    qEntendidoDescripcion: TStringField;
    qOpinion: TQuery;
    qOpinionQueBueno: TSmallintField;
    qOpinionDescripcion: TStringField;
    qGente: TQuery;
    qGenteEMail: TStringField;
    qGenteName: TStringField;
    qGenteDefaultLanguage: TStringField;
    qDelphiEncuestas: TQuery;
    qDelphiEncuestasEMail: TStringField;
    qDelphiEncuestasFecha: TDateTimeField;
    qDelphiEncuestasCursoBueno: TSmallintField;
    qDelphiEncuestasMejorCapitulo: TSmallintField;
    qDelphiEncuestasPeorCapitulo: TSmallintField;
    qDelphiEncuestasQueTantoEntendio: TSmallintField;
    qDelphiEncuestasComentarios: TMemoField;
    DataSource1: TDataSource;
    qStatsMejorCapitulo: TQuery;
    qStatsPeorCapitulo: TQuery;
    qStatsQueTanBueno: TQuery;
    qStatsEntendimiento: TQuery;
    qVistaCompleta: TQuery;
    qVistaCompletaName: TStringField;
    qVistaCompletaEmail: TStringField;
    qVistaCompletaMejorCapitulo: TStringField;
    qVistaCompletaPeorCapitulo: TStringField;
    qVistaCompletaOpinion: TStringField;
    qVistaCompletaEntendido: TStringField;
    qVistaCompletacomentarios: TMemoField;
    qStatsEntendimientoDescripcion: TStringField;
    qStatsEntendimientoCountencQueTantoEntendio: TFloatField;
    qStatsMejorCapituloDescripcion: TStringField;
    qStatsMejorCapituloCuenta: TFloatField;
    qStatsPeorCapituloDescripcion: TStringField;
    qStatsPeorCapituloCuenta: TFloatField;
    qStatsQueTanBuenoDescripcion: TStringField;
    qStatsQueTanBuenoCountCursoBueno: TFloatField;
    ssThread: TSession;
    dbThread: TDatabase;
    procedure DataModuleCreate(Sender: TObject);
    procedure DataModuleDestroy(Sender: TObject);
  private
    { Private declarations }
    Box : TMBox;
    FParseThread : TThread;
    procedure FOnDoneParsing(Sender: TObject);
    function AreWeBusy : Boolean;
  public
    { Public declarations }
    procedure StartParsing(sFileName : String);
    procedure PauseParsing;
    procedure ContinueParsing;
//    procedure StopParsing;
    property Busy : Boolean read AreweBusy;
  end;

var
  EncuestasDM: TEncuestasDM;

implementation

uses MBoxParseThread, EncuestasForm;

{$R *.DFM}

procedure TEncuestasDM.DataModuleCreate(Sender: TObject);
begin

    Box := TMBox.Create;

end;

procedure TEncuestasDM.DataModuleDestroy(Sender: TObject);
begin

  Box.Free;

end;

procedure TEncuestasDM.StartParsing(sFileName : String);
begin

   if not IsanMBox(sFileName) then raise Exception.Create('Este archivo no es un MBox');
   FParseThread := TBoxParser.Create(True);
   Box.MBoxName := sFileName;
   dbThread.Connected := True;
   TBoxParser(FParseThread).MBox   := Box;
   TBoxParser(FParseThread).Database     := dbThread;
   FParseThread.OnTerminate := FOnDoneParsing;
   FParseThread.Resume;

end;

procedure TEncuestasDM.PauseParsing;
begin

  

end;

procedure TEncuestasDM.ContinueParsing;
begin


end;


procedure TEncuestasDM.FOnDoneParsing(Sender: TObject);
begin

  FParseThread.Free;
  FParseThread := Nil;

end;



function TEncuestasDM.AreWeBusy : Boolean;
begin

  Result := FParseThread = Nil; 


end;


end.
