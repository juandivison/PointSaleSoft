unit MBoxParseThread;

interface

uses
  Classes, SysUtils, MBox, DB, DBTables;

type
  TOpinion = ( opNone, opMaravilloso, opExcelente, opMuyBueno, opRegularzon, opMedioMalo, opMalo, opMalisimo );
  TEntendido = ( enNone, enATodo, enCasiTodo, enProbTeoria, enProbPractica, enNada );
  TBoxParser = class(TThread)
  private
    { Private declarations }
    MBoxCurrent : Integer;
    MboxMax     : Integer;
    qGente : TQuery;
    qEncuestas : TQuery;
    FCurrentMessage : String;
    procedure ImportItem( Item : TMailMessage );
    function GetNameFromMaill( Item : TMailMessage ): String;
    function ParseOpinion( Item : TMailMessage ): TOpinion;
    function ParseEntendido( Item : TMailMessage ): TEntendido;
    function GetMejorCapitulo( Item : TMailMessage ) : Integer;
    function GetPeorCapitulo( Item : TMailMessage ) : Integer;
  protected
    procedure FOnMBoxSync( Current, Max : Integer; CustomMsg : String );
    procedure ShowProgress;
    procedure Execute; override;
  public
    MBox : TMBox;
    Database : TDatabase;
  end;

  const
   MARAVILLOSO = 'El Curso es Maravilloso';
   EXCELENTE   = 'El Curso es Excelente'; 
   MUYBUENO    = 'El Curso es Muy bueno';
   REGULARZON  = 'El Curso es Regularzon';
   MEDIOMALO   = 'El Curso es Medio Malo';
   MALO        = 'El Curso es Malo';
   MALISIMO    = 'El Curso es Malisimo!';
   //
   TODO = 'Le he entendido a todo';
   CASITODO = 'Le he entendido a casi todo';
   TEORIA = 'He tenido muchos problemas en la teoria';
   PRACTICA = 'He tenido muchos problemas en la practica';
   NADA = 'No te entiendo nada!';

   // Mejor y peor cap�tulos
   MEJORCAPITULO = 'El Mejor Capitulo ';
   PEORCAPITULO  = 'El PEOR Capitulo ';


implementation

  uses EncuestasForm;


{ Important: Methods and properties of objects in VCL can only be used in a
  method called using Synchronize, for example,

      Synchronize(UpdateCaption);

  and UpdateCaption could look like,

    procedure LeerMBox.UpdateCaption;
    begin
      Form1.Caption := 'Updated in a thread';
    end; }

{ LeerMBox }

procedure TBoxParser.Execute;
var
  i : Integer;
begin

  qGente     := TQuery.Create(Database.Owner);
  qEncuestas := TQuery.Create(Database.Owner);
  qGente.SessionName := Database.SessionName;
  qGente.DatabaseName := Database.DatabaseName;
  qEncuestas.SessionName := Database.SessionName;
  qEncuestas.DatabaseName := Database.DatabaseName;
  qGente.SQL.Add('SELECT * FROM People WHERE EMail = :Email');
  qGente.RequestLive := True;
  qGente.Params[0].DataType := ftString;
  qEncuestas.SQL.Add('SELECT * FROM DelphiEncuestas WHERE EMail = :Email');
  qEncuestas.Params[0].DataType := ftString;
  qEncuestas.RequestLive := True;

  try
    MBox.UpdateProc := FOnMBoxSync;
    MBox.FillMessages;
    // Todo : Add code to import!
    for i := 0 to MBox.MessageList.Count -1 do begin
      FCurrentMessage := 'Reading '+MBox.MessageList.Items[i].MailFrom;
      if Terminated then exit;

      // Update UI
      try
      ImportItem(MBox.MessageList.Items[i]);
      except
        on E: Exception do begin
        end;
      end;

      FOnMBoxSync( i, MBox.MessageList.Count, FCurrentMessage);
    end;
    FOnMBoxSync( 100, 100, 'Done. Thank you!')
  finally
    qGente.Free;
    qEncuestas.Free;
  end;

end;

procedure TBoxParser.FOnMBoxSync( Current, Max : Integer; CustomMsg : String );
begin

  MboxMax := Max;
  MBoxCurrent := Current;
  FCurrentMessage := CustomMsg;
  Synchronize(ShowProgress);

end;

procedure TBoxParser.ShowProgress;
begin

  //  This runs from the context of the main thread.
  mainform.StatusBar1.Panels[0].Text := FCurrentMessage;
  mainform.ProgressBar1.Max := MboxMax;
  mainform.ProgressBar1.Position := MBoxCurrent;

end;


function TBoxParser.GetNameFromMaill( Item : TMailMessage ): String;
var
  i : Integer;
begin

  i := 0;
  Result := '';
  while i < Item.MailBody.Count -1 do begin
    if Pos(',', Item.MailBody.Strings[i]) <> 0
      then Result := Trim(Copy(Item.MailBody.Strings[i], 1, Pos(',', Item.MailBody.Strings[i])-1));
    if Result <> '' then exit;
    Inc(i);
  end;


end;


procedure TBoxParser.ImportItem( Item : TMailMessage );
begin

  // Here we import a single mail item.
  try
    qGente.ParamByName('Email').AsString := Item.MailFrom;
    qGente.Open;
    try
      qGente.Insert;
      qGente.FieldByName('Email').AsString := Trim(Item.MailFrom);
      qGente.FieldByName('Name').AsString := GetNameFromMaill(Item);
      qGente.Post;
    finally
      qGente.Close;
    end;
  except
  end;
  // Now try to parse the survey IF it's a Delphi Tutor Survey
  if Pos('Tutor Delphi', Item.MailSubject) > 0 then
  try
    qEncuestas.ParamByName('Email').AsString := Item.MailFrom;
    qEncuestas.Open;
    try
      qEncuestas.Insert;
      qEncuestas.FieldByName('Email').AsString := Trim(Item.MailFrom);
      qEncuestas.FieldByName('QueTantoEntendio').AsInteger := Ord(ParseEntendido(Item));
      qEncuestas.FieldByName('CursoBueno').AsInteger := Ord(ParseOpinion(Item));
      qEncuestas.FieldByName('MejorCapitulo').AsInteger := GetMejorCapitulo(Item);
      qEncuestas.FieldByName('PeorCapitulo').AsInteger := GetPeorCapitulo(Item);
      qEncuestas.FieldByName('Comentarios').AsString := Item.MailBody.GetText;
      qEncuestas.Post;
    finally
      qEncuestas.Close;
    end;
  except
  end;


end;

function TBoxParser.ParseOpinion( Item : TMailMessage ): TOpinion;
var
  i : Integer;
begin

  i := 0;
  Result := opNone;;
  while i < Item.MailBody.Count -1 do begin
    if Pos(MARAVILLOSO, Item.MailBody.Strings[i]) <> 0 then Result := opMaravilloso;
    if Pos(EXCELENTE , Item.MailBody.Strings[i]) <> 0 then Result := opExcelente;
    if Pos(MUYBUENO  , Item.MailBody.Strings[i]) <> 0 then Result := opMuyBueno;
    if Pos(REGULARZON, Item.MailBody.Strings[i]) <> 0 then Result := opRegularzon;
    if Pos(MEDIOMALO , Item.MailBody.Strings[i]) <> 0 then Result := opMedioMalo;
    if Pos(MALO      , Item.MailBody.Strings[i]) <> 0 then Result := opMalo;
    if Pos(MALISIMO  , Item.MailBody.Strings[i]) <> 0 then Result := opMalisimo;
    Inc(i);
  end;

end;


function TBoxParser.ParseEntendido( Item : TMailMessage ): TEntendido;
var
  i : Integer;
begin

  i := 0;
  Result := enNone;
  while i < Item.MailBody.Count -1 do begin
    if Pos(TODO    , Item.MailBody.Strings[i]) <> 0 then Result := enATodo;
    if Pos(CASITODO, Item.MailBody.Strings[i]) <> 0 then Result := enCasiTodo;
    if Pos(TEORIA  , Item.MailBody.Strings[i]) <> 0 then Result := enProbTeoria;
    if Pos(PRACTICA, Item.MailBody.Strings[i]) <> 0 then Result := enProbPractica;
    if Pos(NADA    , Item.MailBody.Strings[i]) <> 0 then Result := enNada;
    Inc(i);
  end;

end;


function TBoxParser.GetMejorCapitulo( Item : TMailMessage ) : Integer;
var
  sCap : String;
  i : Integer;
  fCapitulo : Double;
begin
  i := 0;
  Result := -1;
  sCap := '';
  while i < Item.MailBody.Count -1 do begin
    if Pos(MEJORCAPITULO, Item.MailBody.Strings[i]) <> 0 then
      sCap := Copy(Item.MailBody.Strings[i],
                   Pos(MEJORCAPITULO,
                       Item.MailBody.Strings[i])+Length(MEJORCAPITULO),
                   Length(Item.MailBody.Strings[i]));
    Inc(i);
  end;
  sCap := Trim(Copy(sCap, 1, Pos(',', sCap)-1));
  if sCap <> '' then begin
    fCapitulo := StrToFloat(sCap);
    Result := Round(fCapitulo * 100);
  end;

end;

function TBoxParser.GetPeorCapitulo( Item : TMailMessage ) : Integer;
var
  sCap : String;
  i : Integer;
  fCapitulo : Double;
begin
  i := 0;
  Result := -1;
  sCap := '';
  while i < Item.MailBody.Count -1 do begin
    if Pos(PEORCAPITULO, Item.MailBody.Strings[i]) <> 0 then
      sCap := Copy(Item.MailBody.Strings[i],
                   Pos(PEORCAPITULO,
                       Item.MailBody.Strings[i])+Length(PEORCAPITULO),
                   Length(Item.MailBody.Strings[i]));
    Inc(i);
  end;
  sCap := Trim(Copy(sCap, 1, Pos(',', sCap)-1));
  if sCap <> '' then begin
    fCapitulo := StrToFloat(sCap);
    Result := Round(fCapitulo * 100);
  end;

end;



end.

