unit mbox;

// This is my poor man's attempt at encapsulating standard unix-style mboxes
// into components. The parser works on my Linux mailboxes for Netscape and Mutt;
// there's no guarantee that they will work on yours but give it a try.

// Although it's readonly and I'm not writing anything to any file, I give no
// guarantee that it will not blow up your mail files, computer, room, house, block or city. I
// do guarantee - it cannot blow up your country unless you tell it to interpret
// the mailbox in a missile silo rather than your computer. :-)

interface
  uses classes, SysUtils;

type

  TUpdateProc = procedure( Current, Max : Integer; CustomMsg : String ) of object;

  TMailMessage = class
  private
    FMailFrom    : String;
    FMailTo      : String;
    FMailSubject : String;
    FMailDate    : String;
    FMailBody    : TStrings;
    FMailMsgID   : String;
    FAttributes  : TStrings;
  public
    property MailFrom : String read FMailFrom write FMailFrom;
    property MailTo   : String read FMailTo write FMailTo;
    property MailSubject : String read FMailSubject write FMailSubject;
    property MailDate    : String read FMailDate    write FMailDate;
    property MailBody : TStrings read FMailBody write FMailBody;
    property MailMsgId    : String read FMailMsgID    write FMailMsgId;
    property Attributes   : TStrings read FAttributes write FAttributes;
    constructor Create;
    destructor Destroy; override;
  end;

  TMessageList = class(TList)
  protected
    function GetItem( ItemNo : Integer ) : TMailMessage;
    procedure SetItem( ItemNo : Integer; Item : TMailMessage );
  public
    property Items[Index: Integer] : TMailMessage read GetItem write SetItem;
    procedure AddMessage( Item : TMailMessage );
    procedure DeleteMessage( Index : Integer );
  end;

  TMBox = class
  private
    FHandle       : TextFile;
  protected
    FMBoxName    : String;   // FileName of the Mbox
    FUpdateProc  : TUpdateProc;
    FMessages    : TMessageList;
    FValidHdrs   : TStrings;
    FDataFile    : TStrings;
    procedure ReadDataFile;
    function getMBoxName : String;
    procedure setMBoxName(Value : String);
    function getUpdateProc : TUpdateProc;
    procedure setUpdateProc(Value : TUpdateProc);
    function ReadHeaders( Data : TStrings; i : Integer; TempMsg : TMailMessage ): Integer;
    function ReadBody( Data : TStrings; i : Integer; TempMsg : TMailMessage ): Integer;
    function IsInHeader( S : String): Boolean;
    function InValidHeaders(S : String): Boolean;
    function StartsWithTaborSpaces( S : String): Boolean;
  public
    procedure FillMessages;
    constructor Create;
    destructor Destroy; override;
    property MessageList : TMessageList read FMessages write FMessages;
  published
    property MBoxName : String read getMBoxName write setMBoxName;
    property UpdateProc : TUpdateProc read GetUpdateProc write SetUpdateProc;
  end;

  function MboxFileSize(MBoxName : String) : Integer;
  // Get all the mbox names in a directory
  procedure GetMBoxNames( Directory : String; Strings : TStrings );
  function IsanMBox( FileName : String ) : Boolean;
  function RealReadln( var F : TextFile ): String;

const
  // These are the headers I recognize
  MBOX_FROMPFX = 'FROM ';
  MBOX_HDR_RETURNPATH = 'RETURN-PATH';
  MBOX_HDR_RECEIVED   = 'RECEIVED';
  MBOX_HDR_INREPLY    = 'IN-REPLY-TO';
  MBOX_HDR_SENDER     = 'SENDER';
  MBOX_HDR_FROM       = 'FROM';
  MBOX_MSG_ID         = 'MESSAGE-ID';
  MBOX_HDR_DATE       = 'DATE';
  MBOX_HDR_MIMEVERSION   = 'MIME-VERSION';
  MBOX_HDR_TO            = 'TO';
  MBOX_HDR_CC            = 'CC';
  MBOX_HDR_FCC            = 'FCC';
  MBOX_HDR_BCC            = 'BCC';
  MBOX_HDR_ORGANIZATION  = 'ORGANIZATION';
  MBOX_HDR_SUBJECT       = 'SUBJECT';
  MBOX_HDR_NEWSGROUPS    = 'NEWSGROUPS';
  MBOX_HDR_REFERENCES    = 'REFERENCES';
  MBOX_HDR_CONTENT_TYPE  = 'CONTENT-TYPE';
  MBOX_HDR_CONTENT_BASE  = 'CONTENT-BASE';
  MBOX_HDR_CONTENT_DISPOSITION = 'CONTENT-DISPOSITION';
  MBOX_HDR_CONTENT_XFER_ENC = 'CONTENT-TRANSFER-ENCODING';
  MBOX_HDR_REPLYTO       = 'REPLY-TO';
  MBOX_HDR_ERRORSTO      = 'ERRORS-TO';
  // Extended headers I recognize as well
  MBOX_HDR_X_MAILER    = 'X-MAILER: ';
  MBOX_HDR_X_ACCEPT_LANG = 'X-ACCEPT-LANGUAGE: ';
  XT_ATTR_PREFIX         = 'X-';  // Extended header Prefix
  A_SEP                  = ': ';

implementation

// MessageList is just a Strongly-types list.
procedure TMessageList.AddMessage( Item : TMailMessage );
begin
  Add( Item );
end;

procedure TMessageList.DeleteMessage( Index : Integer );
begin
  Delete( Index );
end;

function TMessageList.GetItem( ItemNo : Integer ) : TMailMessage;
begin
  Result := TMailMessage( inherited Items[ItemNo] );
end;

procedure TMessageList.SetItem( ItemNo : Integer; Item : TMailMessage );
begin
  Items[ItemNo] := Item;
end;

// Message

constructor TMailMessage.Create;
begin

  FAttributes := TStringList.Create;
  FMailBody   := TStringList.Create;

end;

destructor TMailMessage.Destroy;
begin

  FAttributes.Free;
  FMailBody.Free;
  inherited;

end;



// MBox

constructor TMBox.Create;
begin

  FUpdateProc := Nil;
  FMessages := TMessageList.Create;
  FValidHdrs := TStringList.Create;
  FDataFile  := TStringList.Create;

  // Create the Valid Headers.
  FValidHdrs.Add(MBOX_FROMPFX);
  FValidHdrs.Add(MBOX_HDR_RETURNPATH);
  FValidHdrs.Add(MBOX_HDR_INREPLY);
  FValidHdrs.Add(MBOX_HDR_RECEIVED);
  FValidHdrs.Add(MBOX_HDR_FROM);
  FValidHdrs.Add(MBOX_MSG_ID);
  FValidHdrs.Add(MBOX_HDR_SENDER);
  FValidHdrs.Add(MBOX_HDR_DATE);
  FValidHdrs.Add(MBOX_HDR_X_MAILER);
  FValidHdrs.Add(MBOX_HDR_X_ACCEPT_LANG);
  FValidHdrs.Add(MBOX_HDR_MIMEVERSION);
  FValidHdrs.Add(MBOX_HDR_TO);
  FValidHdrs.Add(MBOX_HDR_SUBJECT);
  FValidHdrs.Add(MBOX_HDR_REFERENCES);
  FValidHdrs.Add(MBOX_HDR_NEWSGROUPS);
  FValidHdrs.Add(MBOX_HDR_CONTENT_TYPE);
  FValidHdrs.Add(MBOX_HDR_CONTENT_BASE);
  FValidHdrs.Add(MBOX_HDR_CONTENT_XFER_ENC);
  FValidHdrs.Add(MBOX_HDR_REPLYTO);
  FValidHdrs.Add(MBOX_HDR_ERRORSTO);
  FValidHdrs.Add(MBOX_HDR_CONTENT_DISPOSITION);
  FValidHdrs.Add(MBOX_HDR_ORGANIZATION);
  FValidHdrs.Add(MBOX_HDR_CC);
  FValidHdrs.Add(MBOX_HDR_FCC);
  FValidHdrs.Add(MBOX_HDR_BCC);

  FValidHdrs.Add(A_SEP);

end;

destructor TMBox.Destroy;
var
  i : Integer;
  msg : TMailMessage;
begin

  for i := FMessages.Count -1 downto 0 do begin
    msg := FMessages.Items[i];
    FMessages.DeleteMessage(i);
    msg.Free;
  end;
  FMessages.Free;
  FValidHdrs.Free;
  FUpdateProc := Nil;
  inherited;

end;

procedure TMBox.setMBoxName(Value : String);
begin

  // mBoxName is a file name. Here we should
  // try to find out if the file exists and is a mailbox.
  if not FileExists(Value) then
     raise Exception.Create('File does not exist');
  if not IsAnMBox(Value) then
     raise Exception.Create('This file is not a Mailbox (at least not in mbox format).');

  FMBoxName := Value;

end;

function TMBox.getMBoxName: String;
begin
  Result := FMBoxName;
end;

function TMBox.getUpdateProc : TUpdateProc;
begin

   Result := FUpdateProc;

end;

procedure TMBox.setUpdateProc(Value : TUpdateProc);
begin

   FUpdateProc := Value;

end;

procedure TMBox.ReadDataFile;
var
  F : TextFile;
  S : String;
  iCurrent, iMax : Integer;
begin

  iCurrent := 0;
  iMax := MboxFileSize(MBoxName);
  if @FUpdateProc <> Nil then FUpdateProc(iCurrent, iMax, 'Opening Mail file for '+MBoxName+'...');
  AssignFile(F, MBoxName);
  FDataFile.Clear;
  Reset(F);
  while not Eof(F) do begin  // Parse the entire file.
    if @FUpdateProc <> Nil then FUpdateProc(iCurrent, iMax, 'Reading Data File...');
    S := RealReadLn(F);
    Inc(iCurrent, Length(S)+1);
    FDataFile.Add(S);
  end;

end;

function TMBox.InValidHeaders(S : String): Boolean;
var
  i : Integer;
begin

  Result := False;
  i := 0;
  while Result = False do begin
    Result := UpperCase(Copy(s, 1, Length(FValidHdrs[i]))) = FValidHdrs[i];
    Inc(i);
    if i = FValidHdrs.Count then exit;
  end;


end;

function TMBox.IsInHeader( S : String): Boolean;
begin

  // This will tell whether a specific message is in the headers depending on the criteria:
  //  1) Line starts with an extended attribute
  //  2) Line Starts with a known attribute
  // It might only be accurate depending on the context. See ReadHeaders' implementation
  Result := False;
  Result := Pos(XT_ATTR_PREFIX, S) = 1;
  if Result = False then Result := InValidHeaders(S);

end;

function TMBox.StartsWithTaborSpaces( S : String): Boolean;
begin

   Result := ( Pos(' ', S) = 1 ) or ( Pos(#9, S) = 1) ;

end;

// This function reads the headers and returns the line offset for which there
// are no more headers (so the calling function knows where to read the body
// from. -1 means no headers were read. Returns the Number of headers read.
function TMbox.ReadHeaders( Data : TStrings; i : Integer; TempMsg : TMailMessage ): Integer;
var
  iPos : Integer;
  bContinue : Boolean;
  bMultiLineSection : Boolean;
  sCurrent : String;
begin

  bContinue := True;
  iPos := 0;
  bMultiLineSection := False;
  while bContinue do begin
    sCurrent := Data[i+iPos];
    if IsInHeader(sCurrent) then begin
      bMultiLineSection :=   ( UpperCase(Copy(sCurrent, 1, Length(MBOX_HDR_RECEIVED))) = MBOX_HDR_RECEIVED)
                           or ( UpperCase(Copy(sCurrent, 1, Length(MBOX_HDR_CONTENT_TYPE))) = MBOX_HDR_CONTENT_TYPE)
                           or ( Copy(sCurrent, Length(sCurrent), 1) = ',' )
                           or ( Copy(sCurrent, Length(sCurrent), 1) = ';' )
                           or ( Copy(sCurrent, Length(sCurrent), 1) = '\' )
                           or ( Copy(sCurrent, Length(sCurrent), 1) = '=' )
                           ;
      if Pos(A_SEP, sCurrent)>0 then sCurrent[Pos(A_SEP, sCurrent)] := '=';
      TempMsg.Attributes.Add(sCurrent);
      Inc(iPos);
    end
    else
    begin
       if bMultiLineSection  then begin
          if StartsWithTaborSpaces(sCurrent)
             then begin
               if TempMsg.Attributes.Count > 0 then
                 TempMsg.Attributes[TempMsg.Attributes.Count-1] := TempMsg.Attributes[TempMsg.Attributes.Count-1]+#13+#10+sCurrent;
               Inc(iPos);
             end else bContinue := False;
       end else bContinue := False;
    end
  end;
  Result := iPos;
  // At the end, check for a mandatory attribute. If it's not there, clear the attributes and return -1
  if TempMsg.Attributes.Values[MBOX_HDR_RETURNPATH] = '' then begin
    TempMsg.Attributes.Clear;
    Result := -1;
  end;

end;


// This function reads the body until the next header starts.
// -1 means no lines were read. Returns the Number of lines read.
// If I Ever decide to handle attachments, here is where I would
// find out about them. For now this is just so I can determine where
// the next message starts 
function TMBox.ReadBody( Data : TStrings; i : Integer; TempMsg : TMailMessage ): Integer;
var
  bContinue : Boolean;
  sCurrent : String;
  sHdrCheck : String;
  iPos : Integer;
begin

  iPos := 0;
  bContinue := True;
  while bContinue do begin
    if i+iPos > Data.Count-1 then break;
    sCurrent := Data[i+iPos];
    if UpperCase(Copy(sCurrent, 1, Length(MBOX_FROMPFX))) = MBOX_FROMPFX then begin
       // Wait until the next 'from ' and then if found check 2 lines ahead to see if it's a header
       sHdrCheck := Data[i+iPos+1];
       bContinue := not IsInHeader(sHdrCheck);
       sHdrCheck := Data[i+iPos+2];
       bContinue := bContinue or ( not IsInHeader(sHdrCheck) );
       if not bContinue then begin
         Dec(iPos);
         break;
       end;
    end;
    TempMsg.MailBody.Add(sCurrent);
    Inc(iPos);
  end;
  Result := iPos;

end;


procedure TMBox.FillMessages;
var
  TempMSG : TMailMessage;  // OldMsg, 
  i, h, iCurrent, iMax, iHowDeep : Integer;
  sCurrent : String;
  AttrState : Integer;  // 1 will be Headers, 2 will be Body.
begin

  if FDataFile.Count = 0 then ReadDataFile;

  // Now this approach is pretty good. Each line simply HAS to fit somewhere
  // within a TMessage. So we start by creating a TMessage and adding Attributes.
  // When we're done adding Attributes, we add Body. If the Body starts finding
  // Attributes again it comes back saying how many lines it read, which means the
  // next one is an attribute again.
  AttrState := 1;  // Start as HEADERS
  iCurrent := 0;
  i:= 0;
  TempMsg := Nil;

  iMax := FDataFile.Count;
  while i < iMax do begin
    iCurrent := i;
    if @FUpdateProc <> Nil then FUpdateProc(iCurrent, iMax, 'Parsing Data File...');
    sCurrent := FDataFile[i];
    // If headers is on, read the headers.
    If AttrState = 1 then begin
      if TempMsg <> Nil then MessageList.AddMessage(TempMsg);
      TempMsg := TMailMessage.Create;
      h := ReadHeaders( FDataFile, i, TempMsg );
      if h = - 1 then begin
        if MessageList.Count > 0 then MessageList.Delete(MessageList.Count-1);
        TempMsg.Free;
        TempMsg := Nil;
        AttrState := 2;
      end else begin
        TempMsg.MailFrom := TempMSG.Attributes.Values[MBOX_HDR_FROM];
        TempMsg.MailSubject := TempMSG.Attributes.Values[MBOX_HDR_SUBJECT];
        TempMsg.MailDate := TempMSG.Attributes.Values[MBOX_HDR_DATE];
        TempMsg.MailMsgId := TempMSG.Attributes.Values[MBOX_MSG_ID];
        i := i + h;
        sCurrent := FDataFile[i];
        // Fill the normal headers
        AttrState := 2;
      end;
    end;
    if AttrState = 2 then begin
       h := ReadBody( FDataFile, i, TempMsg );
       if h <> -1 then begin
         AttrState := 1;
         i := i + h;
       end else begin
         raise Exception.Create('Empty Body (not even one empty liner)?');
         //TempMsg.Free;
         // AttrState := 1;
         // TempMsg := Nil;
         
       end;
    end;
    Inc(i);
  end;
  // At the end, if we have a message on the "in-queue", add it (it's the last one read)
  if TempMsg <> Nil then MessageList.AddMessage(TempMsg);
  
end;

function MboxFileSize(MBoxName : String) : Integer;
var
  rec : TSearchRec;
begin

  Result := 0;
  if FindFirst(MBoxName, faAnyFile, rec) = 0 then Result := Rec.Size;

end;


(*
  This routine puts the filenames of all the mboxes inside
  a directory on a TStrings (that should have been initialized
  previously. It actually verifies that the MBox is in MBox format
  (by checking the first few bytes) so it's safe to just throw
  the funcion at any ole' directory.
*)
procedure GetMBoxNames( Directory : String; Strings : TStrings );
var
  rec : TSearchRec;
  i: Integer;
begin

  // First clear the strings.
  Strings.Clear;
  i := FindFirst(Directory+'/*', faAnyFile, rec);
  if i = 0 then begin
    while i = 0 do begin
      // For each file that is not a directory
     if ( rec.Attr and faDirectory ) = 0 then
     if IsanMBox(Directory+'/'+rec.Name ) then Strings.Add(rec.Name);
     i := FindNext(rec)

    end;
    FindClose(rec);
  end;


end;


// Find out if a file is an mbox.
function IsanMBox( FileName : String ) : Boolean;
var
  F: TextFile;
  ptr : PChar;
  iFromLength : Integer;
  i : Integer;
  sDeleteme : String;
begin


  Result := False;
  iFromLength := Length(MBOX_FROMPFX);
  ptr := AllocMem(iFromLength+1);  // +1 because the last one is #0
  try

    ptr[iFromLength] := #0;
    begin
      try
        AssignFile( F, FileName );
        Reset(F);
        // Read a string of S_From length
        for i := 0 to iFromLength-1 do
           Read(F, ptr[i]);
        if UpperCase(ptr) = MBOX_FROMPFX then Result := True;
        sDeleteme := RealReadLn(F);
      except
        Close(f);
      end;
//         Close(f);
    end;
  finally

    FreeMem(Ptr);
  end;


end;

(*
  RealReadLn is a Platform-independent ReadLn. It reads
  CR and CR/LF the same way.
*)
function RealReadln( var F : TextFile ): String;
var
  ptr : PChar;
  iPos : Integer;
begin

  Result := '';
  ptr := AllocMem(2);  // +1 because the last one is #0
  try

    ptr[1] := #0;
    Read(F, ptr[0]);
    while ( ptr <> #$A ) AND ( ptr <> #$1A ) and ( ptr<>#$0D ) do begin
      Result := Result + ptr;
      Read(F, ptr[0]);
    end;
    // This takes care of DOS files too.
    if ptr = #$0D then Read(F, ptr[0]);

  finally
    FreeMem(Ptr);
  end;

end;


end.
